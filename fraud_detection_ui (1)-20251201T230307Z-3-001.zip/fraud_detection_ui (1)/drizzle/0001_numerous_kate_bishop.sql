CREATE TABLE `fileUploads` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`fileName` varchar(255) NOT NULL,
	`fileKey` varchar(512) NOT NULL,
	`fileUrl` text NOT NULL,
	`mimeType` varchar(64) NOT NULL,
	`fileSize` int NOT NULL,
	`uploadType` enum('transaction_record','fraud_report','document') NOT NULL,
	`description` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `fileUploads_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `fraudPredictions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`transactionId` int NOT NULL,
	`userId` int NOT NULL,
	`predictionResult` enum('fraud','safe') NOT NULL,
	`confidenceScore` int NOT NULL,
	`reasons` text NOT NULL,
	`model` varchar(64) DEFAULT 'random_forest',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `fraudPredictions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `transactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`transactionId` varchar(64) NOT NULL,
	`amount` int NOT NULL,
	`accountAge` int NOT NULL,
	`deviceType` varchar(64) NOT NULL,
	`location` varchar(255) NOT NULL,
	`hopte` varchar(255),
	`lopp` varchar(255),
	`merchantCategory` varchar(128) NOT NULL,
	`transactionTime` varchar(5) NOT NULL,
	`isFraud` int NOT NULL DEFAULT 0,
	`confidence` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `transactions_id` PRIMARY KEY(`id`),
	CONSTRAINT `transactions_transactionId_unique` UNIQUE(`transactionId`)
);
