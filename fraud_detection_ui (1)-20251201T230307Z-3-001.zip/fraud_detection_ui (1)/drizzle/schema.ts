import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Transactions table for storing fraud detection test data
 */
export const transactions = mysqlTable("transactions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  transactionId: varchar("transactionId", { length: 64 }).notNull().unique(),
  amount: int("amount").notNull(),
  accountAge: int("accountAge").notNull(),
  deviceType: varchar("deviceType", { length: 64 }).notNull(),
  location: varchar("location", { length: 255 }).notNull(),
  hopte: varchar("hopte", { length: 255 }),
  lopp: varchar("lopp", { length: 255 }),
  merchantCategory: varchar("merchantCategory", { length: 128 }).notNull(),
  transactionTime: varchar("transactionTime", { length: 5 }).notNull(),
  isFraud: int("isFraud").notNull().default(0),
  confidence: int("confidence").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = typeof transactions.$inferInsert;

/**
 * Fraud predictions table for storing detailed prediction results
 */
export const fraudPredictions = mysqlTable("fraudPredictions", {
  id: int("id").autoincrement().primaryKey(),
  transactionId: int("transactionId").notNull(),
  userId: int("userId").notNull(),
  predictionResult: mysqlEnum("predictionResult", ["fraud", "safe"]).notNull(),
  confidenceScore: int("confidenceScore").notNull(),
  reasons: text("reasons").notNull(),
  model: varchar("model", { length: 64 }).default("random_forest"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type FraudPrediction = typeof fraudPredictions.$inferSelect;
export type InsertFraudPrediction = typeof fraudPredictions.$inferInsert;

/**
 * File uploads table for storing transaction records and reports
 */
export const fileUploads = mysqlTable("fileUploads", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  fileName: varchar("fileName", { length: 255 }).notNull(),
  fileKey: varchar("fileKey", { length: 512 }).notNull(),
  fileUrl: text("fileUrl").notNull(),
  mimeType: varchar("mimeType", { length: 64 }).notNull(),
  fileSize: int("fileSize").notNull(),
  uploadType: mysqlEnum("uploadType", ["transaction_record", "fraud_report", "document"]).notNull(),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type FileUpload = typeof fileUploads.$inferSelect;
export type InsertFileUpload = typeof fileUploads.$inferInsert;