import { Link } from "wouter";
import { Menu, X } from "lucide-react";
import { useState } from "react";

export default function Navigation() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-cyan-500/20">
      <div className="container flex items-center justify-between h-16">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 font-poppins font-bold text-xl">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyan-400 to-pink-500 flex items-center justify-center text-white font-bold">
            AM
          </div>
          <span className="hidden sm:inline gradient-text">Aman.</span>
        </Link>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center gap-8">
          <Link href="/" className="text-foreground/80 hover:text-foreground transition-colors">
            Home
          </Link>
          <Link href="/test" className="text-foreground/80 hover:text-foreground transition-colors">
            Test
          </Link>
          <Link href="/awareness" className="text-foreground/80 hover:text-foreground transition-colors">
            Learn
          </Link>
        </div>

        {/* CTA Buttons */}
        <div className="hidden md:flex items-center gap-4">
          <Link href="/test" className="btn-gradient text-sm">
            Test Transaction
          </Link>
        </div>

        {/* Mobile Menu Button */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="md:hidden p-2 hover:bg-slate-800/50 rounded-lg transition-colors"
        >
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-slate-900/95 backdrop-blur-md border-b border-cyan-500/20">
          <div className="container py-4 flex flex-col gap-4">
            <Link href="/" className="text-foreground/80 hover:text-foreground transition-colors py-2">
              Home
            </Link>
            <Link href="/test" className="text-foreground/80 hover:text-foreground transition-colors py-2">
              Test
            </Link>
            <Link href="/awareness" className="text-foreground/80 hover:text-foreground transition-colors py-2">
              Learn
            </Link>
            <Link href="/test" className="btn-gradient text-sm w-full text-center">
              Try Fraud Test
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
}
