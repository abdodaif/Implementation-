import { Link } from "wouter";
import { Shield, TrendingUp, Zap } from "lucide-react";
import Navigation from "@/components/Navigation";
import AnimatedBackground from "@/components/AnimatedBackground";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";

export default function Home() {
  const { user, isAuthenticated } = useAuth();

  return (
    <div className="min-h-screen bg-background text-foreground relative overflow-hidden">
      <AnimatedBackground />

      {/* Content wrapper */}
      <div className="relative z-10">
        <Navigation />

        {/* Hero Section */}
        <section className="min-h-screen flex items-center justify-center pt-20 pb-20">
          <div className="container max-w-5xl">
            <div className="text-center space-y-8">
              {/* Main Title */}
              <h1 className="text-5xl md:text-6xl lg:text-7xl font-poppins font-bold leading-tight">
                <span className="gradient-text">Aman — Fraud Detection & Analysis</span>
                <br />
                <span className="text-foreground"></span>
                <br />
                <span className="gradient-text"></span>
              </h1>

              {/* Subtitle */}
              <p className="text-xl md:text-2xl text-foreground/80 max-w-3xl mx-auto">
                Smart protection for your financial data.
Add a transaction and get a quick safety check
              </p>

              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row gap-4 justify-center pt-8">
                <Link href="/test" className="btn-gradient text-lg flex items-center justify-center gap-2">
                  <Zap size={20} />
                  Test Transaction
                </Link>
                <Link href="/awareness" className="btn-gradient-pink text-lg flex items-center justify-center gap-2">
                  <TrendingUp size={20} />
                  View Analytics
                </Link>
              </div>

              {/* Info Box */}
              <div className="animated-gradient-border p-6 mt-12 max-w-2xl mx-auto">
                <div className="flex items-start gap-4">
                  <Shield className="text-cyan-400 flex-shrink-0 mt-1" size={24} />
                  <div className="text-left">
                    <p className="text-foreground/90">
                      Experience real-time fraud detection powered by AI and SQL Server
                    </p>
                  </div>
                </div>
              </div>

              {/* Footer Text */}
              <p className="text-foreground/60 text-sm pt-8">
                Securing Digital Transactions with Artificial Intelligence
              </p>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20 border-t border-cyan-500/20">
          <div className="container max-w-5xl">
            <h2 className="text-4xl md:text-5xl font-poppins font-bold text-center mb-16">
              Why Choose Our Platform?
            </h2>

            <div className="grid md:grid-cols-3 gap-8">
              {/* Feature 1 */}
              <div className="glass-card group hover:glow-cyan transition-all duration-300 animate-slide-in-up" style={{ animationDelay: '0.1s' }}>
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-cyan-400 to-cyan-600 flex items-center justify-center mb-4">
                  <Zap className="text-white" size={24} />
                </div>
                <h3 className="text-xl font-poppins font-bold mb-3">Real-Time Detection</h3>
                <p className="text-foreground/80">
                  Instantly analyze transactions and identify potential fraud patterns with advanced AI algorithms.
                </p>
              </div>

              {/* Feature 2 */}
              <div className="glass-card group hover:glow-pink transition-all duration-300 animate-slide-in-up" style={{ animationDelay: '0.2s' }}>
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-pink-400 to-pink-600 flex items-center justify-center mb-4">
                  <Shield className="text-white" size={24} />
                </div>
                <h3 className="text-xl font-poppins font-bold mb-3">Advanced Security</h3>
                <p className="text-foreground/80">
                  Multi-layer protection with machine learning models trained on millions of transactions.
                </p>
              </div>

              {/* Feature 3 */}
              <div className="glass-card group hover:glow-cyan transition-all duration-300 animate-slide-in-up" style={{ animationDelay: '0.3s' }}>
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-cyan-400 to-cyan-600 flex items-center justify-center mb-4">
                  <TrendingUp className="text-white" size={24} />
                </div>
                <h3 className="text-xl font-poppins font-bold mb-3">Detailed Analytics</h3>
                <p className="text-foreground/80">
                  Comprehensive insights and visualizations to understand fraud trends and patterns.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 border-t border-cyan-500/20">
          <div className="container max-w-4xl text-center space-y-8">
            <h2 className="text-4xl md:text-5xl font-poppins font-bold">
              Ready to Protect Your Customers?
            </h2>
            <p className="text-xl text-foreground/80">
              Start testing our fraud detection system today and see how AI can protect your business.
            </p>
            {isAuthenticated ? (
              <Link href="/test" className="btn-gradient text-lg inline-flex items-center gap-2">
                <Zap size={20} />
                Get Started Now
              </Link>
            ) : (
              <a href={getLoginUrl()} className="btn-gradient text-lg inline-flex items-center gap-2">
                <Zap size={20} />
                Sign In to Get Started
              </a>
            )}
          </div>
        </section>
      </div>
    </div>
  );
}
