import { useState } from "react";
import { AlertTriangle, CheckCircle, Loader2 } from "lucide-react";
import Navigation from "@/components/Navigation";
import AnimatedBackground from "@/components/AnimatedBackground";

interface FormData {
  amount: string;
  accountAge: string;
  deviceType: string;
  location: string;
  hopte: string;
  lopp: string;
  merchantCategory: string;
  transactionTime: string;
}

interface PredictionResult {
  isFraud: boolean;
  confidence: number;
  reasons: string[];
}

const mockTransactionHistory = [
  { id: "TXN001", amount: "$1,250", prediction: "Fraud", confidence: "78%", date: "2024-01-15" },
  { id: "TXN002", amount: "$450", prediction: "Fraud", confidence: "65%", date: "2024-01-14" },
  { id: "TXN003", amount: "$89", prediction: "Safe", confidence: "92%", date: "2024-01-13" },
];

export default function FraudTest() {
  const [formData, setFormData] = useState<FormData>({
    amount: "",
    accountAge: "",
    deviceType: "",
    location: "",
    hopte: "",
    lopp: "",
    merchantCategory: "",
    transactionTime: "",
  });

  const [isLoading, setIsLoading] = useState(false);
  const [prediction, setPrediction] = useState<PredictionResult | null>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handlePredict = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500));

    // Mock prediction logic
    const amount = parseFloat(formData.amount) || 0;
    const isFraud = amount > 1000 || Math.random() > 0.6;
    const confidence = Math.floor(Math.random() * 30 + 65);

    setPrediction({
      isFraud,
      confidence,
      reasons: isFraud
        ? [
            "High transaction amount compared to usual pattern.",
            "Device location differs from previous history.",
          ]
        : [
            "Transaction amount within normal range.",
            "Device and location match historical data.",
          ],
    });

    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-background text-foreground relative overflow-hidden">
      <AnimatedBackground />

      <div className="relative z-10">
        <Navigation />

        <section className="pt-32 pb-20">
          <div className="container max-w-5xl">
            <h1 className="text-5xl md:text-6xl font-poppins font-bold text-center mb-4">
              AI-Powered <span className="gradient-text">Transaction Test</span>
            </h1>
            <p className="text-center text-foreground/80 text-lg mb-12">
              Test our fraud detection model with your transaction details
            </p>

            {/* Form Section */}
            <div className="animated-gradient-border p-8 mb-12">
              <form onSubmit={handlePredict} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  {/* Transaction Amount */}
                  <div>
                    <label className="block text-sm font-semibold mb-2">Transaction Amount</label>
                    <input
                      type="number"
                      name="amount"
                      placeholder="Enter amount"
                      value={formData.amount}
                      onChange={handleInputChange}
                      className="input-field"
                      required
                    />
                  </div>

                  {/* Hopte */}
                  <div>
                    <label className="block text-sm font-semibold mb-2">Hopte</label>
                    <input
                      type="text"
                      name="hopte"
                      placeholder="Enter hopte"
                      value={formData.hopte}
                      onChange={handleInputChange}
                      className="input-field"
                      required
                    />
                  </div>

                  {/* Account Age */}
                  <div>
                    <label className="block text-sm font-semibold mb-2">Account Age</label>
                    <input
                      type="number"
                      name="accountAge"
                      placeholder="Days"
                      value={formData.accountAge}
                      onChange={handleInputChange}
                      className="input-field"
                      required
                    />
                  </div>

                  {/* Lopp */}
                  <div>
                    <label className="block text-sm font-semibold mb-2">Lopp</label>
                    <select
                      name="lopp"
                      value={formData.lopp}
                      onChange={handleInputChange}
                      className="input-field"
                      required
                    >
                      <option value="">Select Lopp</option>
                      <option value="option1">Option 1</option>
                      <option value="option2">Option 2</option>
                      <option value="option3">Option 3</option>
                    </select>
                  </div>

                  {/* Device Type */}
                  <div>
                    <label className="block text-sm font-semibold mb-2">Device Type</label>
                    <input
                      type="text"
                      name="deviceType"
                      placeholder="e.g., Mobile, Desktop"
                      value={formData.deviceType}
                      onChange={handleInputChange}
                      className="input-field"
                      required
                    />
                  </div>

                  {/* Merchant Category */}
                  <div>
                    <label className="block text-sm font-semibold mb-2">Merchant Category</label>
                    <input
                      type="text"
                      name="merchantCategory"
                      placeholder="e.g., E-commerce"
                      value={formData.merchantCategory}
                      onChange={handleInputChange}
                      className="input-field"
                      required
                    />
                  </div>

                  {/* Location */}
                  <div>
                    <label className="block text-sm font-semibold mb-2">Location</label>
                    <input
                      type="text"
                      name="location"
                      placeholder="e.g., New York"
                      value={formData.location}
                      onChange={handleInputChange}
                      className="input-field"
                      required
                    />
                  </div>

                  {/* Transaction Time */}
                  <div>
                    <label className="block text-sm font-semibold mb-2">Transaction Time</label>
                    <input
                      type="time"
                      name="transactionTime"
                      value={formData.transactionTime}
                      onChange={handleInputChange}
                      className="input-field"
                      required
                    />
                  </div>
                </div>

                {/* Predict Button */}
                <div className="flex justify-center pt-4">
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="btn-gradient text-lg flex items-center gap-2 disabled:opacity-50"
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="animate-spin" size={20} />
                        Analyzing...
                      </>
                    ) : (
                      "Predict"
                    )}
                  </button>
                </div>
              </form>
            </div>

            {/* Prediction Result */}
            {prediction && (
              <div className="space-y-6 mb-12">
                {/* Result Box */}
                <div className="animated-gradient-border p-8">
                  <h2 className="text-2xl font-poppins font-bold mb-6">Prediction Result</h2>

                  <div
                    className={`rounded-lg p-6 flex items-center gap-4 ${
                      prediction.isFraud
                        ? "bg-red-500/20 border border-red-500/50"
                        : "bg-green-500/20 border border-green-500/50"
                    }`}
                  >
                    {prediction.isFraud ? (
                      <AlertTriangle className="text-red-400 flex-shrink-0" size={32} />
                    ) : (
                      <CheckCircle className="text-green-400 flex-shrink-0" size={32} />
                    )}
                    <div>
                      <h3 className="text-xl font-bold">
                        {prediction.isFraud ? "⚠️ Potential Fraud Detected!" : "✓ Transaction Appears Safe"}
                      </h3>
                    </div>
                  </div>
                </div>

                {/* Confidence & Reasons */}
                <div className="grid md:grid-cols-2 gap-6">
                  {/* Confidence Score */}
                  <div className="animated-gradient-border p-8">
                    <h3 className="text-lg font-poppins font-bold mb-4">Confidence Score</h3>
                    <div className="space-y-4">
                      <div className="relative h-2 bg-slate-800/50 rounded-full overflow-hidden">
                        <div
                          className={`h-full transition-all duration-500 ${
                            prediction.isFraud
                              ? "bg-gradient-to-r from-red-500 to-red-400"
                              : "bg-gradient-to-r from-green-500 to-green-400"
                          }`}
                          style={{ width: `${prediction.confidence}%` }}
                        />
                      </div>
                      <p className="text-sm text-foreground/80">
                        Model Confidence: {prediction.confidence}% {prediction.isFraud ? "Fraud Risk" : "Safe"}
                      </p>
                    </div>
                  </div>

                  {/* Why This Prediction */}
                  <div className="animated-gradient-border p-8">
                    <h3 className="text-lg font-poppins font-bold mb-4">Why this prediction?</h3>
                    <ul className="space-y-2">
                      {prediction.reasons.map((reason, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-sm">
                          <span className="text-cyan-400 mt-1">•</span>
                          <span className="text-foreground/80">{reason}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            )}

            {/* Mini Transaction History */}
            <div className="animated-gradient-border p-8">
              <h2 className="text-2xl font-poppins font-bold mb-6">Mini Transaction History</h2>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-cyan-500/30">
                      <th className="text-left py-3 px-4 text-foreground/80">Transaction ID</th>
                      <th className="text-left py-3 px-4 text-foreground/80">Amount</th>
                      <th className="text-left py-3 px-4 text-foreground/80">Prediction</th>
                      <th className="text-left py-3 px-4 text-foreground/80">Confidence</th>
                      <th className="text-left py-3 px-4 text-foreground/80">Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mockTransactionHistory.map((tx) => (
                      <tr key={tx.id} className="border-b border-slate-800/50 hover:bg-slate-800/30 transition-colors">
                        <td className="py-3 px-4 text-cyan-400">{tx.id}</td>
                        <td className="py-3 px-4">{tx.amount}</td>
                        <td className="py-3 px-4">
                          <span
                            className={`px-3 py-1 rounded-full text-xs font-semibold ${
                              tx.prediction === "Fraud"
                                ? "bg-red-500/20 text-red-400"
                                : "bg-green-500/20 text-green-400"
                            }`}
                          >
                            {tx.prediction}
                          </span>
                        </td>
                        <td className="py-3 px-4">{tx.confidence}</td>
                        <td className="py-3 px-4 text-foreground/80">{tx.date}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Footer */}
            <p className="text-center text-foreground/60 text-sm mt-12">
              Model: Random Forest | Explainability: SHAP | Database: SQL Server (Azure)
            </p>
          </div>
        </section>
      </div>
    </div>
  );
}
