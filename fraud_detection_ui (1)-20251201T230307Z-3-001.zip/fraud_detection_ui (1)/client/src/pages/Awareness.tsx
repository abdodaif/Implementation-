import { useEffect, useState } from "react";
import { Shield, Lock, Bot, TrendingUp, BarChart3, Gauge } from "lucide-react";
import Navigation from "@/components/Navigation";
import AnimatedBackground from "@/components/AnimatedBackground";

export default function Awareness() {
  const [animateChart, setAnimateChart] = useState(false);
  const [visibleCards, setVisibleCards] = useState<number[]>([]);

  useEffect(() => {
    // Trigger animation on mount
    const timer = setTimeout(() => setAnimateChart(true), 200);
    
    // Stagger card animations
    [0, 1, 2].forEach((idx) => {
      setTimeout(() => {
        setVisibleCards((prev) => [...prev, idx]);
      }, idx * 150);
    });

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground relative overflow-hidden">
      <AnimatedBackground />

      <div className="relative z-10">
        <Navigation />

        {/* Hero Section */}
        <section className="pt-32 pb-20 border-b border-cyan-500/20">
          <div className="container max-w-5xl text-center space-y-6">
            <h1 className="text-5xl md:text-6xl font-poppins font-bold animate-slide-in-up">
              <span className="gradient-text">Stay Aware. Stay Secure</span>
            </h1>
            <p className="text-xl text-foreground/80 animate-fade-in" style={{ animationDelay: '0.2s' }}>
              Understand digital fraud risks and learn how AI technology protects you
            </p>
          </div>
        </section>

        {/* Info Cards Section */}
        <section className="py-20 border-b border-cyan-500/20">
          <div className="container max-w-5xl">
            <div className="grid md:grid-cols-3 gap-8">
              {/* Card 1: Common Fraud Types */}
              <div className={`glass-card group hover:glow-cyan transition-all duration-300 h-full ${visibleCards.includes(0) ? 'animate-slide-in-up' : 'opacity-0'}`} style={{ animationDelay: '0.1s' }}>
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-cyan-400 to-cyan-600 flex items-center justify-center mb-4">
                  <Shield className="text-white" size={24} />
                </div>
                <h3 className="text-xl font-poppins font-bold mb-4">Common Fraud Types</h3>
                <ul className="space-y-3 text-foreground/80">
                  <li className="flex items-start gap-2">
                    <span className="text-cyan-400 mt-1">•</span>
                    <span>Phishing</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-cyan-400 mt-1">•</span>
                    <span>Card Cloning</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-cyan-400 mt-1">•</span>
                    <span>Account Takeover</span>
                  </li>
                </ul>
              </div>

              {/* Card 2: Safety Tips */}
              <div className={`glass-card group hover:glow-pink transition-all duration-300 h-full ${visibleCards.includes(1) ? 'animate-slide-in-up' : 'opacity-0'}`} style={{ animationDelay: '0.2s' }}>
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-pink-400 to-pink-600 flex items-center justify-center mb-4">
                  <Lock className="text-white" size={24} />
                </div>
                <h3 className="text-xl font-poppins font-bold mb-4">Safety Tips</h3>
                <ul className="space-y-3 text-foreground/80">
                  <li className="flex items-start gap-2">
                    <span className="text-pink-400 mt-1">•</span>
                    <span>Don't share OTPs</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-pink-400 mt-1">•</span>
                    <span>Verify merchant URLs</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-pink-400 mt-1">•</span>
                    <span>Enable transaction alerts</span>
                  </li>
                </ul>
              </div>

              {/* Card 3: How AI Helps */}
              <div className={`glass-card group hover:glow-cyan transition-all duration-300 h-full ${visibleCards.includes(2) ? 'animate-slide-in-up' : 'opacity-0'}`} style={{ animationDelay: '0.3s' }}>
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-cyan-400 to-cyan-600 flex items-center justify-center mb-4">
                  <Bot className="text-white" size={24} />
                </div>
                <h3 className="text-xl font-poppins font-bold mb-4">How AI Helps</h3>
                <p className="text-foreground/80">
                  Detects unusual transaction behavior and flags anomalies in real-time using advanced machine learning
                  models trained on millions of transactions.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Visual Mini-Dashboard Section */}
        <section className="py-20 border-b border-cyan-500/20">
          <div className="container max-w-5xl">
            <h2 className="text-4xl md:text-5xl font-poppins font-bold text-center mb-16 animate-slide-in-up">
              Visual Mini-Dashboard
            </h2>

            <div className="grid md:grid-cols-3 gap-8">
              {/* Chart 1: Fraud Trends */}
              <div className="glass-card group hover:glow-cyan transition-all duration-300 animate-slide-in-up" style={{ animationDelay: '0.1s' }}>
                <h3 className="text-lg font-poppins font-bold mb-6">Fraud Trends Over Time</h3>
                <div className="h-48 flex items-end justify-center gap-2">
                  {[30, 45, 35, 55, 65, 75, 85].map((value, idx) => (
                    <div
                      key={idx}
                      className={`bg-gradient-to-t from-cyan-400 to-cyan-300 rounded-t transition-all duration-1000 ${
                        animateChart ? "opacity-100" : "opacity-0"
                      }`}
                      style={{
                        width: "12%",
                        height: `${value}%`,
                        transitionDelay: `${idx * 100}ms`,
                      }}
                    />
                  ))}
                </div>
                <p className="text-xs text-foreground/60 text-center mt-4">Last 7 days</p>
              </div>

              {/* Chart 2: Risky Categories */}
              <div className="glass-card group hover:glow-pink transition-all duration-300 animate-slide-in-up" style={{ animationDelay: '0.2s' }}>
                <h3 className="text-lg font-poppins font-bold mb-6">Top Risky Merchant Categories</h3>
                <div className="space-y-3">
                  {[
                    { label: "E-commerce", value: 85 },
                    { label: "Online", value: 72 },
                    { label: "Gaming", value: 68 },
                    { label: "International", value: 55 },
                  ].map((item, idx) => (
                    <div key={idx} className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span className="text-foreground/80">{item.label}</span>
                        <span className="text-pink-400">{item.value}%</span>
                      </div>
                      <div className="h-2 bg-slate-800/50 rounded-full overflow-hidden">
                        <div
                          className={`h-full bg-gradient-to-r from-pink-500 to-pink-400 rounded-full transition-all duration-1000 ${
                            animateChart ? "opacity-100" : "opacity-0"
                          }`}
                          style={{
                            width: `${item.value}%`,
                            transitionDelay: `${idx * 100}ms`,
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Chart 3: Model Accuracy */}
              <div className="glass-card group hover:glow-cyan transition-all duration-300 animate-slide-in-up" style={{ animationDelay: '0.3s' }}>
                <h3 className="text-lg font-poppins font-bold mb-6">Model Accuracy</h3>
                <div className="flex flex-col items-center justify-center h-48">
                  <div className="relative w-32 h-32 flex items-center justify-center">
                    <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                      {/* Background circle */}
                      <circle
                        cx="50"
                        cy="50"
                        r="45"
                        fill="none"
                        stroke="rgba(100, 116, 139, 0.3)"
                        strokeWidth="8"
                      />
                      {/* Progress circle */}
                      <circle
                        cx="50"
                        cy="50"
                        r="45"
                        fill="none"
                        stroke="url(#grad)"
                        strokeWidth="8"
                        strokeDasharray={`${94 * 0.94} ${94 * 3.14}`}
                        className={`transition-all duration-1000 ${animateChart ? "opacity-100" : "opacity-0"}`}
                      />
                      <defs>
                        <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
                          <stop offset="0%" stopColor="rgb(34, 211, 238)" />
                          <stop offset="100%" stopColor="rgb(236, 72, 153)" />
                        </linearGradient>
                      </defs>
                    </svg>
                    <div className="absolute text-center">
                      <p className="text-3xl font-poppins font-bold gradient-text">94%</p>
                      <p className="text-xs text-foreground/60">Accuracy</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Key Statistics Section */}
        <section className="py-20 border-b border-cyan-500/20">
          <div className="container max-w-5xl">
            <h2 className="text-4xl md:text-5xl font-poppins font-bold text-center mb-16 animate-slide-in-up">
              By The Numbers
            </h2>

            <div className="grid md:grid-cols-4 gap-6">
              {[
                { icon: TrendingUp, label: "Fraud Cases Detected", value: "50K+" },
                { icon: BarChart3, label: "Transactions Analyzed", value: "10M+" },
                { icon: Gauge, label: "Detection Accuracy", value: "94%" },
                { icon: Shield, label: "Customers Protected", value: "100K+" },
              ].map((stat, idx) => {
                const Icon = stat.icon;
                return (
                  <div key={idx} className="glass-card text-center animate-slide-in-up" style={{ animationDelay: `${(idx + 1) * 0.1}s` }}>
                    <Icon className="w-8 h-8 mx-auto mb-3 text-cyan-400" />
                    <p className="text-3xl font-poppins font-bold gradient-text mb-2">{stat.value}</p>
                    <p className="text-sm text-foreground/80">{stat.label}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* Closing Section */}
        <section className="py-20">
          <div className="container max-w-4xl text-center space-y-6">
            <h2 className="text-4xl md:text-5xl font-poppins font-bold animate-slide-in-up">
              Awareness is your strongest defense against digital fraud.
            </h2>
            <p className="text-lg text-foreground/80 animate-fade-in" style={{ animationDelay: '0.2s' }}>
              Stay informed, stay vigilant, and leverage AI-powered tools to protect your financial security.
            </p>
          </div>
        </section>
      </div>
    </div>
  );
}
