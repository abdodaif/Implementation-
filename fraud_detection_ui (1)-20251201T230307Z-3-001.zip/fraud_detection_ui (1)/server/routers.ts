import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { createTransaction, getTransactionsByUserId, createFraudPrediction, getPredictionsByUserId, createFileUpload, getFileUploadsByUserId, deleteFileUpload } from "./db";
import { storagePut } from "./storage";
import type { InsertTransaction } from "../drizzle/schema";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Fraud detection and transaction management
  fraud: router({
    // Create a new fraud detection test transaction
    createTransaction: protectedProcedure
      .input(z.object({
        transactionId: z.string(),
        amount: z.number(),
        accountAge: z.number(),
        deviceType: z.string(),
        location: z.string(),
        hopte: z.string().optional(),
        lopp: z.string().optional(),
        merchantCategory: z.string(),
        transactionTime: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        // Simulate fraud detection (in production, call actual ML model)
        const isFraud = Math.random() > 0.7 ? 1 : 0;
        const confidence = Math.floor(Math.random() * 40 + 60);
        
        const transaction = await createTransaction({
          userId: ctx.user.id,
          transactionId: input.transactionId,
          amount: input.amount,
          accountAge: input.accountAge,
          deviceType: input.deviceType,
          location: input.location,
          hopte: input.hopte,
          lopp: input.lopp,
          merchantCategory: input.merchantCategory,
          transactionTime: input.transactionTime,
          isFraud,
          confidence,
        });
        
        // Create fraud prediction record
        const reasons = isFraud ? [
          "High transaction amount compared to usual pattern.",
          "Device location differs from previous history."
        ] : [
          "Transaction matches user profile.",
          "Device and location are consistent with history."
        ];
        
        await createFraudPrediction({
          transactionId: (transaction as any).insertId as number || 1,
          userId: ctx.user.id,
          predictionResult: isFraud ? "fraud" : "safe",
          confidenceScore: confidence,
          reasons: JSON.stringify(reasons),
          model: "random_forest",
        });
        
        return {
          success: true,
          isFraud: isFraud === 1,
          confidence,
          reasons,
        };
      }),
    
    // Get user's transaction history
    getTransactions: protectedProcedure
      .query(async ({ ctx }) => {
        return await getTransactionsByUserId(ctx.user.id);
      }),
    
    // Get user's fraud predictions
    getPredictions: protectedProcedure
      .query(async ({ ctx }) => {
        return await getPredictionsByUserId(ctx.user.id);
      }),
  }),
  
  // File upload and management
  files: router({
    // Upload a file to S3 and store metadata
    uploadFile: protectedProcedure
      .input(z.object({
        fileName: z.string(),
        fileContent: z.string(),
        mimeType: z.string(),
        uploadType: z.enum(["transaction_record", "fraud_report", "document"]),
        description: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        try {
          // Convert base64 to buffer
          const buffer = Buffer.from(input.fileContent, "base64");
          const fileSize = buffer.length;
          
          // Generate unique file key
          const timestamp = Date.now();
          const randomSuffix = Math.random().toString(36).substring(7);
          const fileKey = `${ctx.user.id}/uploads/${input.uploadType}/${timestamp}-${randomSuffix}-${input.fileName}`;
          
          // Upload to S3
          const { url } = await storagePut(fileKey, buffer, input.mimeType);
          
          // Store metadata in database
          await createFileUpload({
            userId: ctx.user.id,
            fileName: input.fileName,
            fileKey,
            fileUrl: url,
            mimeType: input.mimeType,
            fileSize,
            uploadType: input.uploadType,
            description: input.description,
          });
          
          return {
            success: true,
            url,
            fileKey,
          };
        } catch (error) {
          console.error("File upload error:", error);
          throw new Error("Failed to upload file");
        }
      }),
    
    // Get user's uploaded files
    getFiles: protectedProcedure
      .query(async ({ ctx }) => {
        return await getFileUploadsByUserId(ctx.user.id);
      }),
    
    // Delete a file
    deleteFile: protectedProcedure
      .input(z.object({ fileId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        try {
          await deleteFileUpload(input.fileId);
          return { success: true };
        } catch (error) {
          console.error("File deletion error:", error);
          throw new Error("Failed to delete file");
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
